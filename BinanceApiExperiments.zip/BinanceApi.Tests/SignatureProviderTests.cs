using BinanceApi.Configuration;
using BinanceApi.QueryParams;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Utils.Configuration;

namespace BinanceApi.Tests
{
    [TestClass]
    public class SignatureProviderTests
    {
        [TestMethod]
        public void GetSignatureQueryParam()
        {
            var secret = "example secret value";

            var apiCredentialsMock = new Mock<IOptionsLatest<ApiCredentials>>();
            apiCredentialsMock.Setup(x => x.Value).Returns(new ApiCredentials {Secret = secret});

            var sut = new SignatureProvider(apiCredentialsMock.Object);

            var result = sut.GetSignatureQueryParam("timestamp=1626950330172");
            Assert.AreEqual(result, "signature=b0c6a8d80d5430e022a8963c3e240572736c451fbdfec0c2ad2c7e81eef62377");
        }
    }
}