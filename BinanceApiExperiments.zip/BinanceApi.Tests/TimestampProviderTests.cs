﻿using System;
using BinanceApi.QueryParams;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Utils.DateTime;

namespace BinanceApi.Tests
{
    [TestClass]
    public class TimestampProviderTests
    {
        [TestMethod]
        public void GetTimestampQueryParam()
        {
            var dateTimeProviderMock = new Mock<IDateTimeProvider>();
            dateTimeProviderMock.Setup(x => x.GetDateTimeOffset())
                .Returns(DateTimeOffset.Parse("2021-07-22 14:54:12 +03:00"));

            var sut = new TimestampProvider(dateTimeProviderMock.Object);

            var result = sut.GetTimestampQueryParam();
            Assert.AreEqual(result, "timestamp=1626954852000");
        }
    }
}