﻿using System;
using System.Net.Http.Headers;
using BinanceApi.Configuration;
using BinanceApi.QueryParams;
using BinanceApi.QueryRequest;
using BinanceApi.QueryRequestProcessing;
using BinanceApi.SpotAccountTrade.CurrentOpenOrders;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Utils;
using Utils.Configuration;

namespace BinanceApi
{
    public static class BinanceApiBootstrap
    {
        public static void RegisterServices(IServiceCollection services, IConfiguration configuration)
        {
            UtilsBootstrap.RegisterServices(services);

            // settings
            UtilsBootstrap.RegisterOptionsMonitorSingletonWrapper<ApiSettings>(services, configuration);
            UtilsBootstrap.RegisterOptionsMonitorSingletonWrapper<ApiCredentials>(services, configuration);

            // http
            services.AddHttpClient(QueryRunner.HttpClientName, (serviceProvider, client) =>
            {
                var apiSettings = serviceProvider.GetService<IOptionsLatest<ApiSettings>>();
                var apiCredentials = serviceProvider.GetService<IOptionsLatest<ApiCredentials>>();

                client.BaseAddress = new Uri(apiSettings.Value.Endpoint);
                client.Timeout = TimeSpan.FromMilliseconds(apiSettings.Value.Timeout * 1000);

                client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("PostmanRuntime", "7.28.2"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("X-MBX-APIKEY", apiCredentials.Value.Key);
            });

            services.AddTransient<IQueryRunner, QueryRunner>();

            // general
            services.AddSingleton<ISignatureProvider, SignatureProvider>();
            services.AddSingleton<ITimestampProvider, TimestampProvider>();

            // queries
            services.AddSingleton<IQueryMapperProvider, QueryMapperProvider>();

            services.AddSingleton<IQueryMapper, CurrentOpenOrdersQueryMapper>();
        }
    }
}