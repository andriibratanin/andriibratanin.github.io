﻿namespace BinanceApi.Configuration
{
    public class ApiCredentials
    {
        public string Key { get; set; } = "missing value";

        public string Secret { get; set; } = "missing value";
    }
}