﻿namespace BinanceApi.Configuration
{
    public class ApiSettings
    {
        public string Endpoint { get; set; } = "https://api.binance.com";

        public int Timeout { get; set; } = 5;
    }
}