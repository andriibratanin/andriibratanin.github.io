﻿using System.Net.Http;

namespace BinanceApi.Query
{
    public interface IQueryWithSignature : IQuery
    {
        /// <summary>
        /// If HMAC SHA256 signature of the query is mandatory
        /// </summary>
        bool SignatureRequired => true;
    }

    public interface IQueryWithTimestamp : IQuery
    {
        // TODO: Think of moving properties into IQueryWithSignature

        /// <summary>
        /// If Timestamp value is required
        /// </summary>
        bool TimeStampRequired => true;
    }

    public interface IQueryWithSymbol : IQuery
    {
        /// <summary>
        /// Trade symbol (for example BTCUSDT)
        /// </summary>
        string Symbol { get; }

        /// <summary>
        /// If <see cref="Symbol" /> is mandatory
        /// </summary>
        bool SymbolRequired { get; }
    }

    public interface IQueryWithRecvWindow : IQuery
    {
        /// <summary>
        /// How much time the request is valid (in milliseconds)
        /// </summary>
        long? RecvWindow { get; }
    }

    public interface IQuery
    {
        /// <summary>
        ///     API method (GET, POST, etc.)
        /// </summary>
        public HttpMethod HttpMethod { get; }

        /// <summary>
        /// Relative API path
        /// </summary>
        string ApiPath { get; }

        //int Weight { get; }
    }
}