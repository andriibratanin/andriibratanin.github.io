﻿using System;
using System.Security.Cryptography;
using System.Text;
using BinanceApi.Configuration;
using Utils.Configuration;

namespace BinanceApi.QueryParams
{
    /// <summary>
    ///     "Signs" queries to Binance API
    /// </summary>
    public interface ISignatureProvider
    {
        /// <summary>
        ///     Creates a query string signature
        /// </summary>
        /// <param name="queryString">Query string to sign, usually consist at least of "timestamp" parameter with value</param>
        /// <returns></returns>
        string GetSignatureQueryParam(string queryString);
    }

    public class SignatureProvider : ISignatureProvider
    {
        private readonly IOptionsLatest<ApiCredentials> apiCredentials;

        public SignatureProvider(IOptionsLatest<ApiCredentials> apiCredentials)
        {
            this.apiCredentials = apiCredentials;
        }

        public string GetSignatureQueryParam(string queryString)
        {
            var keyBytes = Encoding.UTF8.GetBytes(apiCredentials.Value.Secret);
            var queryStringBytes = Encoding.UTF8.GetBytes(queryString);
            var hmacsha256 = new HMACSHA256(keyBytes);
            var bytes = hmacsha256.ComputeHash(queryStringBytes);

            return "signature=" + BitConverter.ToString(bytes).Replace("-", "").ToLower();
        }
    }
}