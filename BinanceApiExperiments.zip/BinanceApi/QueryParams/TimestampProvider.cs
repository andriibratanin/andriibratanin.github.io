﻿using Utils.DateTime;

namespace BinanceApi.QueryParams
{
    public interface ITimestampProvider
    {
        string GetTimestampQueryParam();
    }

    public class TimestampProvider : ITimestampProvider
    {
        private readonly IDateTimeProvider dateTimeProvider;

        public TimestampProvider(IDateTimeProvider dateTimeProvider)
        {
            this.dateTimeProvider = dateTimeProvider;
        }

        public string GetTimestampQueryParam()
        {
            return "timestamp=" + dateTimeProvider.GetDateTimeOffset().ToUnixTimeMilliseconds();
        }
    }
}