﻿using System;
using BinanceApi.Query;

namespace BinanceApi.QueryRequest
{
    public interface IQueryMapper
    {
        Type SourceQueryType { get; }
    }

    public interface IQueryMapper<T> : IQueryMapper where T : IQuery
    {
        MappedQuery Map(T query);
    }
}