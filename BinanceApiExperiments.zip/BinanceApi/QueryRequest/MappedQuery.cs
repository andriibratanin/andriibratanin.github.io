﻿using System.Net.Http;

namespace BinanceApi.QueryRequest
{
    public class MappedQuery
    {
        public MappedQuery(HttpMethod httpMethod, string url)
        {
            HttpMethod = httpMethod;
            Url = url;
        }

        public HttpMethod HttpMethod { get; }

        public string Url { get; }
    }
}