﻿using System.Collections.Generic;
using System.Linq;
using BinanceApi.Query;

namespace BinanceApi.QueryRequest
{
    public interface IQueryMapperProvider
    {
        IQueryMapper<T> GetQueryMapper<T>(T query) where T : IQuery;
    }

    public class QueryMapperProvider : IQueryMapperProvider
    {
        private readonly IEnumerable<IQueryMapper> mappers;

        public QueryMapperProvider(IEnumerable<IQueryMapper> mappers)
        {
            this.mappers = mappers;
        }

        public IQueryMapper<T> GetQueryMapper<T>(T query) where T : IQuery
        {
            var lookupType = typeof(T);
            return (IQueryMapper<T>) mappers.FirstOrDefault(x => x.SourceQueryType == lookupType);
        }
    }
}