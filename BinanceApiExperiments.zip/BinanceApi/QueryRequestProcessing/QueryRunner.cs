﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using BinanceApi.QueryRequest;
using BinanceApi.QueryResponse;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace BinanceApi.QueryRequestProcessing
{
    public interface IQueryRunner
    {
        Task<QueryResponse<T>> RunQuery<T>(MappedQuery query) where T : class;
    }

    public class QueryRunner : IQueryRunner
    {
        public const string HttpClientName = "BinanceAPI";

        private readonly HttpClient httpClient;
        private readonly ILogger<IQueryRunner> logger;

        public QueryRunner(
            IHttpClientFactory httpClientFactory,
            ILogger<IQueryRunner> logger)
        {
            httpClient = httpClientFactory.CreateClient(HttpClientName);
            this.logger = logger;
        }

        public async Task<QueryResponse<T>> RunQuery<T>(MappedQuery query) where T : class
        {
            logger.LogInformation($"Http Request: {query.HttpMethod} {query.Url}");

            var request = new HttpRequestMessage(query.HttpMethod, query.Url);

            var response = await httpClient.SendAsync(request);

            var originalRetryAfterHeader = response.Headers.RetryAfter;
            if (originalRetryAfterHeader != null)
                logger.LogError(
                    $"Retry-After (original) header is present: Date={originalRetryAfterHeader.Date?.Date.ToString("yyyy-MM-dd HH:mm:ss")}, DeltaSeconds={originalRetryAfterHeader.Delta?.TotalSeconds}");

            if (response.Headers.TryGetValues("Retry-After", out var retryAfterValues))
            {
                var customRetryAfter = retryAfterValues.FirstOrDefault();
                logger.LogError($"Retry-After (custom) header is present: Value={customRetryAfter} (seconds?)");
            }

            var content = await response.Content.ReadAsStringAsync();

/* Example of content
var content = @"[{""symbol"":""BTCUSDT"",""orderId"":5472335686,""orderListId"":-1,""clientOrderId"":""and_7ed3ae93b25b42149b72f0570faf889c"",""price"":""65000.00000000"",""origQty"":""0.00348600"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1617821356143,""updateTime"":1617821356143,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""BTCUSDT"",""orderId"":5654631645,""orderListId"":-1,""clientOrderId"":""and_ba28d2338d4f4584ad8069df296b4732"",""price"":""60000.00000000"",""origQty"":""0.00395200"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1619200467539,""updateTime"":1619200467539,""isWorking"":true,
""origQuoteOrderQty"":""0.00000000""},{""symbol"":""BTTUSDT"",""orderId"":269715713,""orderListId"":-1,""clientOrderId"":""and_ea8cf6e88a8f4d39ab8078c45a59d761"",""price"":""0.02000000"",""origQty"":""10000.00000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1617818666043,""updateTime"":1617818666043,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""DOGEUSDT"",""orderId"":1471179036,""orderListId"":-1,""clientOrderId"":""and_3b6ef3b87c5441a4bf5f1b6d74d280ed"",""price"":""0.85000000"",""origQty"":""2792.00000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626499223859,""updateTime"":1626499223859,""isWorking"":true,""origQuoteOrderQty"":""0.00
000000""},{""symbol"":""WRXUSDT"",""orderId"":138264981,""orderListId"":-1,""clientOrderId"":""and_3585a533799f4caf97fe8654f979db5e"",""price"":""8.00000000"",""origQty"":""33.70000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1617703927444,""updateTime"":1617703927444,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""STMXUSDT"",""orderId"":88088405,""orderListId"":-1,""clientOrderId"":""and_26bfb97bd5e24bb5aac774144a6d9c17"",""price"":""0.10000000"",""origQty"":""1536.00000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1616317521234,""updateTime"":1616317521234,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT""
,""orderId"":1004537738,""orderListId"":-1,""clientOrderId"":""and_120d44eecd47442e8bbef9d82446e299"",""price"":""40000.00000000"",""origQty"":""0.00256400"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1623788094928,""updateTime"":1623788094928,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1005378031,""orderListId"":-1,""clientOrderId"":""and_946c4d6f06684919beb376493c83236e"",""price"":""39000.00000000"",""origQty"":""0.00263100"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1623823907531,""updateTime"":1623823907531,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1006547831,""o
rderListId"":-1,""clientOrderId"":""and_691187e264b741dca0990a81e6c7fc4d"",""price"":""38000.00000000"",""origQty"":""0.00270200"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1623870231866,""updateTime"":1623870231866,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1045170891,""orderListId"":-1,""clientOrderId"":""and_1cb75e0818d34c8394ac15b516c284b7"",""price"":""37000.00000000"",""origQty"":""0.00277700"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1625696606502,""updateTime"":1625696606502,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1052725494,""orderListId"":-1,""clientOrd
erId"":""and_b275739563084344b39b9d4e26ee4122"",""price"":""34500.00000000"",""origQty"":""0.00297900"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626124762193,""updateTime"":1626124762193,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1053671987,""orderListId"":-1,""clientOrderId"":""and_503a35e3c85d46a29b9eb78185944b9a"",""price"":""35800.00000000"",""origQty"":""0.00298300"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626177497988,""updateTime"":1626177497988,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1054394181,""orderListId"":-1,""clientOrderId"":""and_866b5f59539442
0b9713ac28fe2fda06"",""price"":""33500.00000000"",""origQty"":""0.00310500"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626216941536,""updateTime"":1626216941536,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1054835183,""orderListId"":-1,""clientOrderId"":""and_26a2762a425544b3ac3a2d2db9906497"",""price"":""32500.00000000"",""origQty"":""0.00322500"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626237196476,""updateTime"":1626237196476,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1057307385,""orderListId"":-1,""clientOrderId"":""and_d037413b175041648aab20cb5e3ac4e4"",""pric
e"":""31250.00000000"",""origQty"":""0.00333300"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626372018168,""updateTime"":1626372018168,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1058497820,""orderListId"":-1,""clientOrderId"":""and_5dfc7fd6509942e9b4b192c8a545b843"",""price"":""30200.00000000"",""origQty"":""0.00346100"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626430493643,""updateTime"":1626430493643,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1066447358,""orderListId"":-1,""clientOrderId"":""and_2cb566b530d9478686531a7075c0f12e"",""price"":""29300.00000000"",""or
igQty"":""0.00355600"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626899545692,""updateTime"":1626899545692,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1066453269,""orderListId"":-1,""clientOrderId"":""and_eb9b0903508947bd9b34c045a1db7a79"",""price"":""27000.00000000"",""origQty"":""0.00370300"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""BUY"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626899852382,""updateTime"":1626899852382,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1066453754,""orderListId"":-1,""clientOrderId"":""and_aebc1cb13f824b3586708e26c87bcca3"",""price"":""26000.00000000"",""origQty"":""0.00384600"",""exe
cutedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""BUY"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626899870089,""updateTime"":1626899870089,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""YFIUSDT"",""orderId"":1066454015,""orderListId"":-1,""clientOrderId"":""and_2f8798c9c1cf4e48a816ebe897a99dad"",""price"":""25000.00000000"",""origQty"":""0.00400000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""BUY"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1626899881926,""updateTime"":1626899881926,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""FILUSDT"",""orderId"":440787178,""orderListId"":-1,""clientOrderId"":""and_d668ec4ecf7c4aba8a71bc197da40e5e"",""price"":""230.00000000"",""origQty"":""2.17000000"",""executedQty"":""0.00000000"",""cumm
ulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1617559102516,""updateTime"":1617559102516,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""LITUSDT"",""orderId"":107309460,""orderListId"":-1,""clientOrderId"":""and_3fb7f1edf9274498bae6c9796d21a22b"",""price"":""12.00000000"",""origQty"":""8.33000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1620043990701,""updateTime"":1620043990701,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""LINAUSDT"",""orderId"":2987892,""orderListId"":-1,""clientOrderId"":""and_909eda96d56b478894d9e9b572e1460c"",""price"":""0.75000000"",""origQty"":""352.11000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""
status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1616184616099,""updateTime"":1616184616099,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""LINAUSDT"",""orderId"":18248193,""orderListId"":-1,""clientOrderId"":""and_950784a56a254fa5a3469c43bb8ac91a"",""price"":""0.17000000"",""origQty"":""2345.90000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce"":""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1618658914548,""updateTime"":1618658914548,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""},{""symbol"":""LINAUSDT"",""orderId"":28747722,""orderListId"":-1,""clientOrderId"":""and_fad18d12a10644e5932da1d22d2f5e85"",""price"":""0.13000000"",""origQty"":""769.23000000"",""executedQty"":""0.00000000"",""cummulativeQuoteQty"":""0.00000000"",""status"":""NEW"",""timeInForce""
:""GTC"",""type"":""LIMIT"",""side"":""SELL"",""stopPrice"":""0.00000000"",""icebergQty"":""0.00000000"",""time"":1620104408726,""updateTime"":1620104408726,""isWorking"":true,""origQuoteOrderQty"":""0.00000000""}]";
//*/
            //Console.WriteLine(content);

            try
            {
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException)
            {
                if (!string.IsNullOrWhiteSpace(content))
                {
                    ErrorResponse errorResult = null;
                    try
                    {
                        errorResult = JsonConvert.DeserializeObject<ErrorResponse>(content);
                    }
                    catch (Exception ex)
                    {
                        logger.LogError(ex, $"Was not able to deserialize HTTP error response: {content}");
                    }

                    throw new ApiCallFailedException(response.StatusCode, response.ReasonPhrase, errorResult);
                }

                throw;
            }

            var t = JsonConvert.DeserializeObject<T>(content);

            return new QueryResponse<T>(t);
        }
    }
}