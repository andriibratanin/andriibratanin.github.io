﻿using System;
using System.Net;

namespace BinanceApi.QueryResponse
{
    public class ApiCallFailedException : Exception
    {
        public ApiCallFailedException(HttpStatusCode statusCode, string reason, ErrorResponse response)
            : base($"Api request failed with code {statusCode}, reason '{reason}'")
        {
            StatusCode = statusCode;
            ReasonPhrase = reason;
            Response = response;
        }

        public HttpStatusCode StatusCode { get; }

        public string ReasonPhrase { get; }

        public ErrorResponse Response { get; }
    }
}