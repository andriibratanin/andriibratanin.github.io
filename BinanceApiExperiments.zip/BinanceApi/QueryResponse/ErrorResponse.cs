﻿namespace BinanceApi.QueryResponse
{
    public class ErrorResponse
    {
        public int Code { get; set; } // Example: -2014

        public string Msg { get; set; } // Example: "API-key format invalid."
    }
}