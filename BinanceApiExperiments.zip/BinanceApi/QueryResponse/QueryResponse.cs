﻿namespace BinanceApi.QueryResponse
{
    public class QueryResponse<T> where T : class
    {
        public QueryResponse(T data)
        {
            Data = data;
        }

        public T Data { get; }
    }
}