﻿using System;
using System.Collections.Generic;
using BinanceApi.Query;
using BinanceApi.QueryParams;
using BinanceApi.QueryRequest;

namespace BinanceApi.SpotAccountTrade
{
    public abstract class BaseQueryMapper<T> : IQueryMapper<T> where T : IQuery
    {
        private readonly ISignatureProvider signatureProvider;
        private readonly ITimestampProvider timestampProvider;

        protected BaseQueryMapper(
            ITimestampProvider timestampProvider,
            ISignatureProvider signatureProvider)
        {
            this.timestampProvider = timestampProvider;
            this.signatureProvider = signatureProvider;
        }

        public Type SourceQueryType => typeof(T);

        public MappedQuery Map(T query)
        {
            if (query == null) throw new ArgumentNullException(nameof(query));

            var apiPath = query.ApiPath;

            var queryParams = CustomMappingLogic(query) ?? new List<string>();

            AddSymbolToQueryParams(query, queryParams);

            AddRecvWindowToQueryParams(query, queryParams);

            AddTimeStampToQueryParams(query, queryParams);

            // signature must be the last query parameter!
            AddSignatureToQueryParams(query, queryParams);

            var queryString = GetQueryString(queryParams);
            var url = BuildUrl(apiPath, queryString);

            return new MappedQuery(
                query.HttpMethod,
                url
            );
        }

        private static string BuildUrl(string apiPath, string queryString)
        {
            if (queryString.Length > 0)
                queryString = "?" + queryString;

            var url = apiPath + queryString;
            return url;
        }

        private void AddSignatureToQueryParams(T query, List<string> queryParams)
        {
            if (query is IQueryWithSignature)
            {
                var queryString = GetQueryString(queryParams);
                queryParams.Add(signatureProvider.GetSignatureQueryParam(queryString));
            }
        }

        private void AddTimeStampToQueryParams(T query, List<string> queryParams)
        {
            if (query is IQueryWithTimestamp) queryParams.Add(timestampProvider.GetTimestampQueryParam());
        }

        private static void AddRecvWindowToQueryParams(T query, List<string> queryParams)
        {
            if (query is IQueryWithRecvWindow queryWithRecvWindow &&
                queryWithRecvWindow.RecvWindow.HasValue)
                queryParams.Add(nameof(IQueryWithRecvWindow.RecvWindow).ToLower() + "=" +
                                queryWithRecvWindow.RecvWindow.Value);
        }

        private static void AddSymbolToQueryParams(T query, List<string> queryParams)
        {
            if (query is IQueryWithSymbol queryWithSymbol)
            {
                if (!string.IsNullOrWhiteSpace(queryWithSymbol.Symbol))
                    queryParams.Add(nameof(IQueryWithSymbol.Symbol).ToLower() + "=" +
                                    Uri.EscapeDataString(queryWithSymbol.Symbol));
                else if (queryWithSymbol.SymbolRequired)
                    throw new ArgumentException($"Missing mandatory {nameof(IQueryWithSymbol.Symbol)} value");
            }
        }

        protected virtual List<string> CustomMappingLogic(T query)
        {
            return null;
        }

        private string GetQueryString(IEnumerable<string> queryParams)
        {
            return string.Join('&', queryParams);
        }
    }
}