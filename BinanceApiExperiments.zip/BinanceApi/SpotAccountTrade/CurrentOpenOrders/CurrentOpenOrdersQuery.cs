﻿using System;
using System.Net.Http;
using BinanceApi.Query;

namespace BinanceApi.SpotAccountTrade.CurrentOpenOrders
{
    // https://binance-docs.github.io/apidocs/spot/en/#current-open-orders-user_data
    public class CurrentOpenOrdersQuery :
        IQuery,
        IQueryWithSignature,
        IQueryWithTimestamp,
        IQueryWithSymbol,
        IQueryWithRecvWindow
    {
        public CurrentOpenOrdersQuery(string symbol, long? recvWindow)
        {
            if (recvWindow > 60000)
                throw new ArgumentException($"{nameof(recvWindow)} cannot be greater than 60000");

            Symbol = symbol;

            RecvWindow = recvWindow;
        }

        public int Weight => string.IsNullOrWhiteSpace(Symbol) ? 40 : 3;
        public HttpMethod HttpMethod => HttpMethod.Get;

        public string ApiPath => "/api/v3/openOrders";

        public long? RecvWindow { get; }

        public string Symbol { get; }

        public bool SymbolRequired => false;
    }
}