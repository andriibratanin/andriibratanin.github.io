﻿using BinanceApi.QueryParams;

namespace BinanceApi.SpotAccountTrade.CurrentOpenOrders
{
    public class CurrentOpenOrdersQueryMapper : BaseQueryMapper<CurrentOpenOrdersQuery>
    {
        public CurrentOpenOrdersQueryMapper(
            ISignatureProvider signatureProvider,
            ITimestampProvider timestampProvider
        ) : base(timestampProvider, signatureProvider)
        {
        }
    }
}