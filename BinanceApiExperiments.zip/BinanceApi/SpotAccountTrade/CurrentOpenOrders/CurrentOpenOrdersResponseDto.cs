﻿using System;
using System.Globalization;

namespace BinanceApi.SpotAccountTrade.CurrentOpenOrders
{
    public class CurrentOpenOrdersResponseDto
    {
        public string Symbol { get; set; }

        public long OrderId { get; set; }

        //public long OrderListId { get; set; }

        public string Price { get; set; }

        public string OrigQty { get; set; }

        //public string ExecutedQty { get; set; }

        //public string CummulativeQuoteQty { get; set; }

        public string Status { get; set; }

        public string Side { get; set; }

        public string Time { get; set; }

        public double GetPrice => Price == null ? 0 : double.Parse(Price, CultureInfo.InvariantCulture);

        public double GetQuantity => OrigQty == null ? 0 : double.Parse(OrigQty, CultureInfo.InvariantCulture);

        //public double GetExecutedQuantity => double.Parse(ExecutedQty);

        public DateTime GetTime()
        {
            var unixTimeStamp = long.Parse(Time);
            return DateTimeOffset.FromUnixTimeMilliseconds(unixTimeStamp).DateTime;
        }
    }

    /* Data examples:
    [
      {
        "symbol": "LTCBTC",
        "orderId": 1,
        "orderListId": -1, //Unless OCO, the value will always be -1
        "clientOrderId": "myOrder1",
        "price": "0.1",
        "origQty": "1.0",
        "executedQty": "0.0",
        "cummulativeQuoteQty": "0.0",
        "status": "NEW",
        "timeInForce": "GTC",
        "type": "LIMIT",
        "side": "BUY",
        "stopPrice": "0.0",
        "icebergQty": "0.0",
        "time": 1499827319559,
        "updateTime": 1499827319559,
        "isWorking": true,
        "origQuoteOrderQty": "0.000000"
      }
    ] 

    {
        "symbol": "BTCUSDT",
        "orderId": 5472335686,
        "orderListId": -1,
        "clientOrderId": "and_7ed3ae93b25b42149b72f0570faf889c",
        "price": "65000.00000000",
        "origQty": "0.00348600",
        "executedQty": "0.00000000",
        "cummulativeQuoteQty": "0.00000000",
        "status": "NEW",
        "timeInForce": "GTC",
        "type": "LIMIT",
        "side": "SELL",
        "stopPrice": "0.00000000",
        "icebergQty": "0.00000000",
        "time": 1617821356143,
        "updateTime": 1617821356143,
        "isWorking": true,
        "origQuoteOrderQty": "0.00000000"
    },
    */
}