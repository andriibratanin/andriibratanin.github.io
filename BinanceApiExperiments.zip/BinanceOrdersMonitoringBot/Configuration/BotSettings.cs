﻿namespace BinanceOrdersMonitoringBot.Configuration
{
    public class BotSettings
    {
        public int OrdersPollingInterval { get; set; } = 60;

        public string TradePairOfInterest { get; set; } = "BTCUSDT";
    }
}