﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using BinanceApi.QueryRequest;
using BinanceApi.QueryRequestProcessing;
using BinanceApi.QueryResponse;
using BinanceApi.SpotAccountTrade.CurrentOpenOrders;
using BinanceOrdersMonitoringBot.Configuration;
using BinanceOrdersMonitoringBot.Persistence;
using BinanceOrdersMonitoringBot.Presentation;
using Microsoft.Extensions.Logging;
using Synology;
using Utils.Configuration;

namespace BinanceOrdersMonitoringBot.Logic
{
    public interface IBinanceBot
    {
        Task Run(CancellationToken cancellationToken);
        void OnExit(object sender, EventArgs e);
    }

    public class BinanceBot : IBinanceBot
    {
        private readonly IOptionsLatest<BotSettings> botSettings;
        private readonly ILogger<BinanceBot> logger;
        private readonly IOrdersHistory ordersHistory;
        private readonly ICurrentOpenOrdersResponseDtoMapper ordersMapper;
        private readonly IQueryMapperProvider queryMapperProvider;
        private readonly IQueryRunner queryRunner;
        private readonly IReportSender reportSender;
        private readonly IWebhookSender webHookSender;

        public BinanceBot(
            ILogger<BinanceBot> logger,
            IOptionsLatest<BotSettings> botSettings,
            IWebhookSender webHookSender,
            IQueryMapperProvider queryMapperProvider,
            IQueryRunner queryRunner,
            IOrdersHistory ordersHistory,
            ICurrentOpenOrdersResponseDtoMapper ordersMapper,
            IReportSender reportSender)
        {
            this.logger = logger;
            this.botSettings = botSettings;
            this.webHookSender = webHookSender;
            this.queryMapperProvider = queryMapperProvider;
            this.queryRunner = queryRunner;
            this.ordersHistory = ordersHistory;
            this.ordersMapper = ordersMapper;
            this.reportSender = reportSender;
        }

        public async Task Run(CancellationToken cancellationToken)
        {
            logger.LogInformation("Bot started");
            logger.LogInformation("Press Ctrl+C to exit");

            await webHookSender.SendWebhook("Bot started");

            var previousOrders = ordersHistory.LoadOrders();

            var query = new CurrentOpenOrdersQuery(botSettings.Value.TradePairOfInterest, null);
            var queryMapper = queryMapperProvider.GetQueryMapper(query);

            while (!cancellationToken.IsCancellationRequested)
            {
                var skipReport = false;

                IReadOnlyCollection<string> currentOrders = new List<string>();
                try
                {
                    var mappedQuery = queryMapper.Map(query);
                    var response = await queryRunner.RunQuery<List<CurrentOpenOrdersResponseDto>>(mappedQuery);

                    currentOrders = ordersMapper.Map(response);

                    ordersHistory.SaveOrders(currentOrders);
                }
                catch (ApiCallFailedException apiCallFailedException)
                {
                    /* Binance note on HTTP errors:
                    HTTP 4XX return codes are used for malformed requests; the issue is on the sender's side.
                    HTTP 403 return code is used when the WAF Limit (Web Application Firewall) has been violated.
                    HTTP 429 return code is used when breaking a request rate limit.
                    HTTP 418 return code is used when an IP has been auto-banned for continuing to send requests after receiving 429 codes. WARNING: .Net CORE DOES NOT HAVE SUCH CODE DEFINED IN STATUS
               >>>> A Retry-After header is sent with a 418 or 429 responses and will give the number of seconds required to wait, in the case of a 429, to prevent a ban, or, in the case of a 418, until the ban is over.
                    HTTP 5XX return codes are used for internal errors; the issue is on Binance's side. It is important to NOT treat this as a failure operation; the execution status is UNKNOWN and could have been a success.
                    */
                    if (apiCallFailedException.StatusCode == HttpStatusCode.Forbidden ||
                        apiCallFailedException.StatusCode == HttpStatusCode.TooManyRequests)
                    {
                        // ban or throttling
                        logger.LogError("!!!Banned!!!");
                        await webHookSender.SendWebhook("*TOO MANY REQUESTS!!!*");

                        // it is better to crush here to avoid permanent ban
                        throw;
                    }

                    // other API-related error
                    // NOTE: bad request can also be caused by too short recvWindow (thus server could not respond in a timely manner)
                    logger.LogError(apiCallFailedException, apiCallFailedException.Response.Msg);
                    await webHookSender.SendWebhook("*Error:*\n" + apiCallFailedException.Response.Msg);

                    skipReport = true;
                }
                catch (HttpRequestException httpRequestException)
                {
                    // HTTP errors like "Host cannot be reached"
                    logger.LogError(httpRequestException, "HTTP Request failed");
                    await webHookSender.SendWebhook("*Error:*\n" + httpRequestException.Message);

                    skipReport = true;
                }
                catch (TaskCanceledException taskCanceledException)
                {
                    // timeouts
                    logger.LogError(taskCanceledException, "Timeout");
                    await webHookSender.SendWebhook("*Error (timeout):*\n" + taskCanceledException.Message);

                    skipReport = true;
                }
                catch (Exception exception)
                {
                    logger.LogError(exception, "Unknown error");
                    await webHookSender.SendWebhook("*Error (unknown):*\n" + exception.Message);

                    throw;
                }

                if (!skipReport)
                {
                    await reportSender.SendTradeOrdersReport(previousOrders, currentOrders);

                    previousOrders = currentOrders;
                }

                try
                {
                    await Task.Delay(botSettings.Value.OrdersPollingInterval * 1000, cancellationToken);
                }
                catch (TaskCanceledException)
                {
                    // it is ok to ignore the exception as we were just asked to gracefully exit
                }
            }
        }

        // On Exit event (to make sure an user can see the corresponding message in the chat)
        public void OnExit(object sender, EventArgs e)
        {
            webHookSender.SendWebhook("Bot exited");

            logger.LogInformation("Bot exiting");
        }
    }
}