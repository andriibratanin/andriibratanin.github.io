﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BinanceOrdersMonitoringBot.Persistence
{
    public interface IOrdersHistory
    {
        IReadOnlyCollection<string> LoadOrders();
        void SaveOrders(IReadOnlyCollection<string> orders);
    }

    public class OrdersHistoryStorageMock : IOrdersHistory
    {
        // these values left hard-coded because it does not makes sense to use configuration for a mock
        private const string lastOrdersFilename = "orders.txt";
        private const int discardDataAfterMinutes = 60;

        public IReadOnlyCollection<string> LoadOrders()
        {
            return File.Exists(lastOrdersFilename) &&
                   File.GetLastWriteTime(lastOrdersFilename) > DateTime.Now.AddMinutes(-discardDataAfterMinutes)
                ? File.ReadAllLines(lastOrdersFilename).ToList()
                : new List<string>();
        }

        public void SaveOrders(IReadOnlyCollection<string> orders)
        {
            File.WriteAllLines(lastOrdersFilename, orders);
        }
    }
}