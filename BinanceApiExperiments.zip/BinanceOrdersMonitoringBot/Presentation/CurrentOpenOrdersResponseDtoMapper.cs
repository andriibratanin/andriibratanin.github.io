﻿using System.Collections.Generic;
using BinanceApi.QueryResponse;
using BinanceApi.SpotAccountTrade.CurrentOpenOrders;

namespace BinanceOrdersMonitoringBot.Presentation
{
    public interface ICurrentOpenOrdersResponseDtoMapper
    {
        IReadOnlyCollection<string> Map(QueryResponse<List<CurrentOpenOrdersResponseDto>> response);
    }

    public class CurrentOpenOrdersResponseDtoMapper : ICurrentOpenOrdersResponseDtoMapper
    {
        public IReadOnlyCollection<string> Map(QueryResponse<List<CurrentOpenOrdersResponseDto>> response)
        {
            var orders = new List<string>();

            foreach (var data in response.Data)
                orders.Add(
                    $"{data.GetTime():yyyy.MM.dd HH:mm:ss} {data.Status} {data.Side} {data.Symbol} {data.GetPrice} {data.GetQuantity}");

            return orders;
        }
    }
}