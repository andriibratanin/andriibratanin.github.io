﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Synology;

namespace BinanceOrdersMonitoringBot.Presentation
{
    public interface IReportSender
    {
        Task SendTradeOrdersReport(
            IReadOnlyCollection<string> previousOrders,
            IReadOnlyCollection<string> currentOrders);
    }

    public class ReportSender : IReportSender
    {
        private readonly ILogger<ReportSender> logger;
        private readonly IWebhookSender webHookSender;

        public ReportSender(
            ILogger<ReportSender> logger,
            IWebhookSender webHookSender
        )
        {
            this.logger = logger;
            this.webHookSender = webHookSender;
        }

        public async Task SendTradeOrdersReport(
            IReadOnlyCollection<string> previousOrders,
            IReadOnlyCollection<string> currentOrders)
        {
            if (!previousOrders.Any())
            {
                // first run
                var message = string.Join('\n', currentOrders);
                logger.LogInformation("Current orders:\n" + message);
                await webHookSender.SendWebhook("*Current orders:*\n" + message);
            }
            else
            {
                // compare
                var closedOrders = previousOrders.Except(currentOrders);
                var openedOrders = currentOrders.Except(previousOrders);

                if (closedOrders.Any())
                {
                    var message = string.Join('\n', closedOrders);
                    logger.LogInformation("Closed orders:\n" + message);
                    await webHookSender.SendWebhook("*Closed orders ( @user ):*\n" + message);
                }

                if (openedOrders.Any())
                {
                    var message = string.Join('\n', openedOrders);
                    logger.LogInformation("New orders:\n" + message);
                    await webHookSender.SendWebhook("*New orders:*\n" + message);
                }
            }
        }
    }
}