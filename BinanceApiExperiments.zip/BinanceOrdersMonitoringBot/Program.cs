﻿using System;
using System.Threading;
using System.Threading.Tasks;
using BinanceOrdersMonitoringBot.Logic;
using BinanceOrdersMonitoringBot.Setup;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BinanceOrdersMonitoringBot
{
    internal static class Program
    {
        private static IServiceProvider serviceProvider;
        private static IConfiguration configuration;

        private static CancellationTokenSource cancellationTokenSource;

        private static async Task<int> Main(string[] args)
        {
            // setup
            configuration = ConfigurationSetup.GetApplicationConfiguration(args);
            serviceProvider = ServicesRegistration.RegisterServices(configuration);

            cancellationTokenSource = new CancellationTokenSource();

            // composition root
            var bot = serviceProvider.GetService<IBinanceBot>();

            // startup
            Console.Title = "== Binance Trade Orders Monitoring Bot == ";

            AppDomain.CurrentDomain.ProcessExit += bot.OnExit;

            Console.CancelKeyPress += CtrlCAction;

            try
            {
                await bot.Run(cancellationTokenSource.Token);

                return 0;
            }
            catch (Exception)
            {
                return 1;
            }
        }

        private static void CtrlCAction(object sender, ConsoleCancelEventArgs e)
        {
            e.Cancel = true;

            Console.WriteLine("Got exit signal");

            cancellationTokenSource.Cancel();
        }
    }
}