﻿using System;
using System.IO;
using Microsoft.Extensions.Configuration;

namespace BinanceOrdersMonitoringBot.Setup
{
    internal static class ConfigurationSetup
    {
        public static IConfiguration GetApplicationConfiguration(string[] args)
        {
            var currentDirectory = Directory.GetCurrentDirectory();

            var configurationBuilder = new ConfigurationBuilder()
                .SetBasePath(currentDirectory)
                .AddJsonFile("appsettings.json", true, true);

            // this simplification was made to not use IHostingEnvironment with its dependencies
            // https://docs.microsoft.com/en-us/aspnet/core/fundamentals/configuration/?view=aspnetcore-5.0
            var environmentName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            if (!string.IsNullOrWhiteSpace(environmentName))
                configurationBuilder.AddJsonFile($"appsettings.{environmentName}.json", true,
                    true);

            return configurationBuilder
                .AddEnvironmentVariables()
                .AddCommandLine(args)
                .Build();
        }
    }
}