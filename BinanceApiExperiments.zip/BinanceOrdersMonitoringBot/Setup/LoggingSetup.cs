﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace BinanceOrdersMonitoringBot.Setup
{
    public class LoggingSetup
    {
        public static void AddLogging(IConfiguration configuration, IServiceCollection services)
        {
            services.AddLogging(configure => configure.AddConsole().SetMinimumLevel(LogLevel.Debug));

            if (Enum.TryParse<LogLevel>(configuration["LOG_LEVEL"], out var logLevel))
                services.Configure<LoggerFilterOptions>(options => options.MinLevel = logLevel);
            else
                services.Configure<LoggerFilterOptions>(options => options.MinLevel = LogLevel.Error);
        }
    }
}