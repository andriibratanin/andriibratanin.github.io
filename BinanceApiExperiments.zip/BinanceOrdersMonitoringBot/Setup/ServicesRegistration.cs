﻿using System;
using BinanceApi;
using BinanceOrdersMonitoringBot.Configuration;
using BinanceOrdersMonitoringBot.Logic;
using BinanceOrdersMonitoringBot.Persistence;
using BinanceOrdersMonitoringBot.Presentation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Synology;
using Utils;

namespace BinanceOrdersMonitoringBot.Setup
{
    internal static class ServicesRegistration
    {
        public static IServiceProvider RegisterServices(IConfiguration configuration)
        {
            var services = new ServiceCollection();
            services.AddSingleton(configuration);

            LoggingSetup.AddLogging(configuration, services);

            BinanceApiBootstrap.RegisterServices(services, configuration);
            SynologyBootstrap.RegisterServices(services, configuration);

            AddBotServices(services, configuration);

            return services.BuildServiceProvider();
        }

        private static void AddBotServices(ServiceCollection services, IConfiguration configuration)
        {
            // settings
            UtilsBootstrap.RegisterOptionsMonitorSingletonWrapper<BotSettings>(services, configuration);

            // logic-related stuff
            services.AddTransient<IOrdersHistory, OrdersHistoryStorageMock>();
            services.AddTransient<IReportSender, ReportSender>();
            services.AddTransient<ICurrentOpenOrdersResponseDtoMapper, CurrentOpenOrdersResponseDtoMapper>();
            services.AddSingleton<IBinanceBot, BinanceBot>();
        }
    }
}