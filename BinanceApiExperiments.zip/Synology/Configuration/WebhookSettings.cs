﻿namespace Synology.Configuration
{
    public class WebhookSettings
    {
        public string Endpoint { get; set; } = "missing value";

        public string Url { get; set; } = "/webapi/entry.cgi?api=SYNO.Chat.External&method=incoming&version=2";

        public string Token { get; set; } = "missing value";

        public int Timeout { get; set; } = 5;
    }
}