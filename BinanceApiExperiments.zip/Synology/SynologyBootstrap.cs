﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Synology.Configuration;
using Utils;
using Utils.Configuration;

namespace Synology
{
    public static class SynologyBootstrap
    {
        public static void RegisterServices(IServiceCollection services, IConfiguration configuration)
        {
            // settings
            UtilsBootstrap.RegisterOptionsMonitorSingletonWrapper<WebhookSettings>(services, configuration);

            // http
            services.AddHttpClient(WebhookSender.HttpClientName, (serviceProvider, client) =>
                {
                    var webhookSettings = serviceProvider.GetService<IOptionsLatest<WebhookSettings>>();

                    client.BaseAddress = new Uri(webhookSettings.Value.Endpoint);
                    client.Timeout = TimeSpan.FromMilliseconds(webhookSettings.Value.Timeout * 1000);
                    client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("PostmanRuntime", "7.28.2"));
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                })
                .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
                {
                    // Disable SSL verification
                    ClientCertificateOptions = ClientCertificateOption.Manual,
                    ServerCertificateCustomValidationCallback =
                        (httpRequestMessage, cert, certChain, policyErrors) => true
                });

            // chat webhook
            services.AddSingleton<IWebhookSender, WebhookSender>();
        }
    }
}