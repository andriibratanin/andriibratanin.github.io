﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Synology.Configuration;
using Utils.Configuration;

namespace Synology
{
    public interface IWebhookSender
    {
        Task SendWebhook(string payload);
    }

    public class WebhookSender : IWebhookSender
    {
        public const string HttpClientName = "SynologyWebhook";
        private readonly HttpClient httpClient;
        private readonly ILogger<WebhookSender> logger;

        private readonly IOptionsLatest<WebhookSettings> webhookSettings;

        public WebhookSender(
            IOptionsLatest<WebhookSettings> webhookSettings,
            IHttpClientFactory httpClientFactory,
            ILogger<WebhookSender> logger)
        {
            this.webhookSettings = webhookSettings;
            this.logger = logger;

            httpClient = httpClientFactory.CreateClient(HttpClientName);
        }

        public async Task SendWebhook(string payload)
        {
            var encodedPayload = "&payload=" + Uri.EscapeDataString("{\"text\":\"" + payload + "\"}");

            var queryString = webhookSettings.Value.Url + "&token=" +
                              Uri.EscapeDataString($"\"{webhookSettings.Value.Token}\"") + encodedPayload;

            var request = new HttpRequestMessage(HttpMethod.Get, queryString);

            try
            {
                var response = await httpClient.SendAsync(request);

                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Was not able to sent a chat message using the webhook: {ex.Message}");
            }
        }
    }
}