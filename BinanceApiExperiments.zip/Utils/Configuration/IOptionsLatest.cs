﻿namespace Utils.Configuration
{
    public interface IOptionsLatest<T> where T : class
    {
        T Value { get; }
    }
}