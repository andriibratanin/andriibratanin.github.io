﻿using Microsoft.Extensions.Options;

namespace Utils.Configuration
{
    // This wrapper CAN be used in singletons (while usual IOptionsSnapshot cannot)
    // and it provides IMMEDIATE settings values updates (IOptionsSnapshot is registered as Transient in DI)
    public class OptionsMonitorSingletonWrapper<T> : IOptionsLatest<T> where T : class
    {
        public OptionsMonitorSingletonWrapper(IOptionsMonitor<T> settings)
        {
            Value = settings.CurrentValue;

            // Hook on the OnChange event of the monitor
            _ = settings.OnChange(Listener);
        }

        public T Value { get; private set; }

        private void Listener(T settings)
        {
            Value = settings;
        }
    }
}