﻿using System;

namespace Utils.DateTime
{
    public interface IDateTimeProvider
    {
        System.DateTime GetDateTime();

        DateTimeOffset GetDateTimeOffset();
    }

    public class DateTimeProvider : IDateTimeProvider
    {
        public DateTimeOffset GetDateTimeOffset()
        {
            return DateTimeOffset.Now;
        }

        public System.DateTime GetDateTime()
        {
            return System.DateTime.Now;
        }
    }
}