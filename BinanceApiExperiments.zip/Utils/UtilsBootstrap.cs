﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Utils.Configuration;
using Utils.DateTime;

namespace Utils
{
    public static class UtilsBootstrap
    {
        public static void RegisterServices(IServiceCollection services)
        {
            services.AddSingleton<IDateTimeProvider, DateTimeProvider>();
        }

        public static void RegisterOptionsMonitorSingletonWrapper<T>(IServiceCollection services,
            IConfiguration configuration) where T : class
        {
            services.AddOptions<T>().Bind(configuration.GetSection(typeof(T).Name));
            services.AddSingleton<IOptionsLatest<T>>(sp =>
                new OptionsMonitorSingletonWrapper<T>(sp.GetService<IOptionsMonitor<T>>()));
        }
    }
}