This project is a POC made for one of technical interviews.

It polls the Binance API for user's opened orders in one particular trade pair and reports "changes" (i.e. opened and closed trades) into a Synology NAS chat.

It includes integrations with:
- Binance (public API, requires pre-generated trader's key)
- Synology Chat (web-hook, required pre-generated token)

NOTE: Sensitive data like Binance API key and secret as well as Synology Chat webhook token can be configured using environment variables (for example, via `launchSettings.json` file) or in `appsettings.json`.

Links
---
- [Binance API Postman](https://github.com/binance/binance-api-postman)
- [Binance API Documentation](https://binance-docs.github.io/apidocs/spot/en/#change-log)
- [Binance REST API](https://github.com/binance/binance-spot-api-docs/blob/master/rest-api.md)
- [Binance REST API Error Codes](https://github.com/binance/binance-spot-api-docs/blob/master/errors.md)
- [Synology NAS Chat Webhooks](https://kb.synology.com/en-nz/DSM/tutorial/How_to_configure_webhooks_and_slash_commands_in_Chat_Integration)